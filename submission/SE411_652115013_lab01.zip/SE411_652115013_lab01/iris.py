import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

iris= pd.read_csv("Iris.csv")

print(iris.head(10))
